<div class="hero">
    <?php $image = get_field('heroImg'); ?>
    <img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" />
</div>